package com.hcl.hclassessment2.config;

public class CustomerConfig {
}
