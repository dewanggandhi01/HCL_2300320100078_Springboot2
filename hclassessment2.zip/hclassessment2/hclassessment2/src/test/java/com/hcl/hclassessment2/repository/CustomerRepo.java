package com.hcl.hclassessment2.repository;

import org.springframework.stereotype.Repository;

@Repository
public class CustomerRepo {

}
