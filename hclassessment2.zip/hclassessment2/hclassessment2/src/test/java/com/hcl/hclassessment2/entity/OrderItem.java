package com.hcl.hclassessment2.entity;

public class OrderItem {
    private String orderItemId;
    private String customerOrder;
    private String product;
    private String quantity;
    private String price;

}
