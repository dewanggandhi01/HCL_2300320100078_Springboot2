package com.hcl.hclassessment2.auth;

public class CustomerAuth {

}
