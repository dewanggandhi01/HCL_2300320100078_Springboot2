package com.hcl.hclassessment2.entity;

public class Product {
    private String productId;
    private String productName;
    private String description;
    private String price;
    private String quantity;
    private String category;

}
