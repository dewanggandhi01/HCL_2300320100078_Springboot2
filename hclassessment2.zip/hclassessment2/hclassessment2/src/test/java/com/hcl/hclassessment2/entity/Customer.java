package com.hcl.hclassessment2.entity;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.Id;
import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;

@Entity
@Table(name = "customer")
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="customer_id", nullable=false)
    private Long customerId;

    @Column(name="customer_name", nullable=false)
    private String customerName;

    @Column(name="email", nullable=false)
    private String email;

    @Column(name="password", nullable=false)
    private String password;

    @Column(name="mobile", nullable=false)
    private String mobile;

    @Column(name="city", nullable=false)
    private String city;

    public Customer() {};

    public Customer(Long customerId, String customerName, String email, String password, BigInteger mobile, String city){
        this.customerId=customerId;
        this.customerName=customerName;
        this.email=email;
        this.password=password;
        this.mobile=mobile;
        this.city=city;

    }

    public Long getCustomerId(){
        return customerId;
    }

    public void setCustomerId(Long customerId){
        this.customerId=customerId;
    }

    public String getCustomerName(){
        return customerName;
    }

    public  void setCustomerName(String CustomerName){
        this.customerName=customerName;
    }

    public String getEmail(){
        return email;
    }

    public void setEmail(String email){
    }

    public String getPassword(){
        return password;
    }

    public String getCity(){
        return city;
    }

    public BigInteger getMobile(){
        return mobile;
    }

}








