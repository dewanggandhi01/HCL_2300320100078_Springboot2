package com.hcl.hclassessment2.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.Id;
import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;

import javax.smartcardio.CardTerminal;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;

@Entity
@Table(name = "cart_item")
public class CartItem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="cartItemId", nullable=false)
    private Long cartItemId;

    @Column(name="cart", nullable=false)
    private Cart cart;

    @Column(name="product", nullable=false)
    private Product product;

    @Column(name="quantity", nullable=false)
    private Integer quantity;

    @Column(name="price", nullable=false)
    private Double price;

    public CartItem(){};

    public CartItem(Long cartItemId, Customer customer, LocalDate createdDate){
        this.cartId=cartId;
        this.customer=customer;
        this.createdDate=createdDate;
    }

    public Long getCartId(){
        return cartId;
    }

    public void setCartId(Long cartId){
        this.cartId=cartId;
    }

    public Customer getCustomer(){
        return customer;
    }

    public void setCustomer(Customer customer){
        this.customer=customer;
    }

    public LocalDate getCreatedDate(){
        return createdDate;
    }
    public void setCreatedDate(LocalDate createdDate){
        this.createdDate=createdDate;
    }

}


