package com.hcl.hclassessment2.entity;

public class CustomerOrder {
    private String orderId;
    private String customer;
    private String orderDate;
    private String totalAmount;
    private String orderStatus;

}
