package com.hcl.hclassessment2.entity;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.Id;
import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;

@Entity
@Table(name = "cart")
public class Cart {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="cartId", nullable=false)
    private Long cartId;

    @Column(name="customer", nullable=false)
    private Customer customer;

    @Column(name="createdDate", nullable=false)
    private LocalDate createdDate;

    public Cart(){};

    public Cart(Long cartId, Customer customer, LocalDate createdDate){
        this.cartId=cartId;
        this.customer=customer;
        this.createdDate=createdDate;
    }

    public Long getCartId(){
        return cartId;
    }

    public void setCartId(Long cartId){
        this.cartId=cartId;
    }

    public Customer getCustomer(){
        return customer;
    }

    public void setCustomer(Customer customer){
        this.customer=customer;
    }

    public LocalDate getCreatedDate(){
        return createdDate;
    }
    public void setCreatedDate(LocalDate createdDate){
        this.createdDate=createdDate;
    }

}
